import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import json
import os
from azure.storage.blob import BlobServiceClient
import time

# --- ページ設定 ---
st.set_page_config(page_title="自分史・人生グラフの作成", layout="wide")

st.title("人生グラフの作成")
st.info("左のフォームにあなたの人生体験を入力し、「登録」ボタンを押してあなたの人生グラフを完成させましょう。")
st.markdown("""
<div style="background-color: #fff4e5; color: #663c00; padding: 16px; border-radius: 8px; border-left: 5px solid #ffa117;">
    ⚠️ 人生グラフの<u style="color:#442900">作成時間は<strong>1時間30分</strong></u>です。<u style="color:#442900">各自で時間を測り、<strong>15件</strong>を目標に登録</u>してください。
</div>
""", unsafe_allow_html=True)
#st.warning("人生グラフの作成時間は1時間30分です。各自で時間を測り、15件を目標に登録してください。")
#st.markdown("---")

# --- セッション状態で「ユーザー入力データ」を管理 ---
if 'user_events' not in st.session_state:
    st.session_state.user_events = []
    initial_event = {
        "順番": 0,
        "年齢": 0,
        "幸福度": 0,
        "エピソード": "誕生",
        "最重要": False
    }
    if st.session_state.user_data.get("life", None) == None:
        st.session_state.user_events = [initial_event]
    else:
        st.session_state.user_events = st.session_state.user_data.get("life")

if 'graph_completed' not in st.session_state:
    st.session_state.graph_completed = False

# フォームの初期値をセッション状態から設定
if "input_form_age" not in st.session_state:
    st.session_state["input_form_age"] = -1
if "input_form_happiness" not in st.session_state:
    st.session_state["input_form_happiness"] = 0
if "input_form_episode" not in st.session_state:
    st.session_state["input_form_episode"] = ""
if "reset_form" not in st.session_state:
    st.session_state["reset_form"] = False

def make_graph():
    # --- ページを左右に分割 ---
    col1, col2 = st.columns([1, 1])

    # --- 左カラム：自分史の入力と表示 ---
    with col1:
        st.subheader("1. 人生体験を入力・登録")
        categories = ["学業", "仕事", "人間関係", "健康", "趣味・娯楽"]
        #with st.expander("入力の際の注意事項"):
        st.info("""
            年齢 : 同じ年齢の出来事を複数入力できます。\n
            エピソード : あなたの体験をその時の感情や考え方の変化を含めて記述してください。
                下記の例以外にも、家族や仕事、健康、趣味・娯楽など思いつくものをなんでも記述してください。
        """)
        with st.expander("エピソード例（学業）"):
            st.info("""
                第一志望の大学受験に失敗した。\n
                自分の実力に自信があり、絶対に合格できると思い込んでいた。\n
                不合格の文字を見た瞬間、頭が真っ白になり、絶望感と周りへの申し訳なさでいっぱいになった。\n
                人生で初めての大きな挫折を経験し、謙虚さを学んだ。結果がすべてではなく、そこから何を学ぶかが重要だと考えられるようになった。\n
            """)
        with st.expander("エピソード例（友人関係）"):
            st.info("""
                自分とは価値観が全く違う友人との出会い。\n
                自分の意見や考え方が一番だと思っており、少し頑固だったかもしれない。\n
                当初は意見が合わず衝突ばかりだったが、相手の話をじっくり聞くうちに、自分の知らない世界があることに気づかされた。\n
                自分とは異なる視点を受け入れることの大切さを学んだ。この経験を通じて、より柔軟で寛容な考え方ができるようになった。\n
            """)

        if st.session_state.reset_form:
            st.session_state.input_form_age = -1
            st.session_state.input_form_happiness = 0
            st.session_state.input_form_episode = ""
            st.session_state.reset_form = False

        with st.form("input_form", clear_on_submit=False):
            st.write("##### 新しい出来事を入力してください")
            form_col1, form_col2 = st.columns(2)
            with form_col1:
                st.number_input("年齢（だいたいでも可）", min_value=-1, max_value=120, step=1, key="input_form_age")
                st.slider("幸福度（-100: 最悪 〜 100: 最高）", -100, 100, key="input_form_happiness")
            with form_col2:
                st.text_area("具体的なエピソード(25文字以上入力してください)", height=200, key="input_form_episode")
            submitted = st.form_submit_button("この出来事を登録する")

            if submitted:
                age = st.session_state.input_form_age
                happiness = st.session_state.input_form_happiness
                episode = st.session_state.input_form_episode
                if age < 0 :
                    st.warning("年齢を正しく入力してください。半角で入力されていますか？")
                elif happiness == 0:
                    st.warning("幸福度を設定してください。")
                elif len(episode) < 25:
                    st.warning(f"エピソードを25文字以上入力してください。現在{len(episode)}/30")
                else:
                    new_event = {
                        "順番": len(st.session_state.user_events),
                        "年齢": age, "エピソード": episode,
                        "幸福度": happiness, "最重要": False
                    }
                    st.session_state.user_events.append(new_event)
                    st.session_state.reset_form = True
                    st.success("出来事を登録しました！")
                    st.rerun()

    with col2:
        st.subheader("2. あなたの記録一覧")
        st.info("""
                この一覧表はダブルクリックして編集できます。幸福度を増やしたり減らしたりして、人生グラフのバランスを調整してください。
                同じ年齢の出来事は、最重要にチェックを付けることでその出来事の幸福度のみが反映されます。
                """)
        #st.caption("この表は直接編集・削除が可能です。")

        if st.session_state.user_events:
            df_to_edit = pd.DataFrame(st.session_state.user_events).sort_values(by="年齢").reset_index(drop=True)
            edited_df = st.data_editor(
                df_to_edit,
                key="data_editor_key",
                #on_change=sync_data_editor_changes,
                width="stretch",
                hide_index=True,
                num_rows="dynamic",
                column_config={
                    "年齢": st.column_config.NumberColumn("年齢", min_value=-1, max_value=120, required=True),
                    "エピソード": st.column_config.TextColumn("エピソード", width="large", required=True),
                    "幸福度": st.column_config.NumberColumn("幸福度", min_value=-100, max_value=100, required=True),
                    "最重要": st.column_config.CheckboxColumn("最重要", required=False)
                },
                column_order=["最重要", "年齢", "幸福度", "エピソード"]
            )
            st.session_state.user_events = edited_df.to_dict('records')

    # --- 人生グラフの描画 ---
    #st.markdown("---")
    st.subheader("3. 人生グラフ")
    st.info("""年齢や幸福度のバランスは記録一覧から調整できます。同じ年齢の体験は、最重要が選択されていない場合、幸福度が平均されています。
    """)
    # 「最重要」を優先するカスタム集計関数
    def process_age_group(group):
        important_events = group[group['最重要'] == True]

        if not important_events.empty:
            priority_event = important_events.iloc[0]
            return pd.Series({
                '幸福度': priority_event['幸福度'],
                'エピソード': priority_event['エピソード'],
            })
        else:
            return pd.Series({
                '幸福度': group['幸福度'].mean(),
                'エピソード': ' / '.join(group['エピソード']),
            })

    if st.session_state.user_events:
        raw_plot_df = pd.DataFrame(st.session_state.user_events)
        raw_plot_df = raw_plot_df.dropna(subset=['年齢'])
        raw_plot_df = raw_plot_df[pd.to_numeric(raw_plot_df['年齢'], errors='coerce').notna()]

        if not raw_plot_df.empty:
            raw_plot_df['年齢'] = raw_plot_df['年齢'].astype(int)

            agg_plot_df = raw_plot_df.groupby('年齢').apply(process_age_group).reset_index()
            agg_plot_df = agg_plot_df.sort_values(by="年齢").reset_index(drop=True)

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=agg_plot_df['年齢'], y=agg_plot_df['幸福度'], mode='lines+markers',
                marker=dict(size=10), line=dict(shape='spline', smoothing=0.8),
                hovertemplate=(
                    "<b>年齢</b>: %{x}歳<br>" + "<b>幸福度</b>: %{y:.1f}<br>" +
                    "<b>エピソード</b>: %{customdata}" +
                    "<extra></extra>"
                ),
                customdata=agg_plot_df['エピソード']
            ))
            fig.add_hline(y=0, line_dash="dash", line_color="gray")
            fig.update_layout(
                xaxis_title="年齢", yaxis_title="幸福度",
                xaxis=dict(range=[0, agg_plot_df['年齢'].max() + 5 if not agg_plot_df.empty else 100]),
                yaxis=dict(range=[-105, 105]), height=600
            )
            st.plotly_chart(
                fig,
                config={
                    "displayModeBar": True,
                    "displaylogo": False,
                    "scrollZoom": False
                },
                use_container_width=True
            )
        else:
            st.info("グラフを描画するには、有効な「年齢」が入力された出来事が必要です。")
    else:
        st.info("出来事を入力すると、ここにグラフが表示されます。")

    if st.button("作成完了", disabled=not st.session_state.user_events or len(st.session_state.user_events)<=5):
        st.success("作成お疲れ様です！次へお進みください")
        st.session_state.graph_completed = True
        st.session_state.user_data["life"] = st.session_state.user_events

    if not st.session_state.graph_completed:
        st.warning("人生体験は5件以上登録してください。")
    else:
        if st.button("次へ"):
            st.session_state.role = "Info2"
            st.session_state.user_data["life"] = st.session_state.user_events
            st.session_state.user_data["graph_end"]= time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            st.rerun()

if __name__ == "__main__":
    try:
        make_graph()
    except Exception as e:
        st.error(f"エラーが発生しました。ご迷惑をおかけします。{e}")
        st.info("再度同じユーザーIDを入力すると、進捗を復元できます。")

        user_data = {}
        user_data["user_id"] = st.session_state.user_data.get("user_id", "")
        user_data["gender"] = st.session_state.user_data.get("gender", "")
        user_data["age"] = st.session_state.user_data.get("age", "未回答")
        user_data["job"] = st.session_state.user_data.get("job", "未回答")
        #user_data["bfi"] = st.session_state.user_data.get("bfi", None)
        #user_data["emcs"] = st.session_state.user_data.get("emcs", None)
        user_data["tipi"] = st.session_state.user_data.get("tipi", None)
        user_data["pvq"] = st.session_state.user_data.get("pvq", None)
        user_data["life"] = st.session_state.user_data.get("life", None)
        user_data["error_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

        # --- Azure Blob Storage 接続情報 ---
        # 環境変数から接続文字列とコンテナ名を取得
        # これらは後ほどAzureの画面で設定します
        CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
        CONTAINER_NAME = "results" # 作成するコンテナ名

        def save_to_blob(data):
            """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
            if not CONNECT_STR:
                st.error("Azureの接続文字列が設定されていません。")
                return

            try:
                file_name = f"survey_result_{user_data['user_id']}.json"

                # JSONデータに変換
                json_data = json.dumps(data, indent=2, ensure_ascii=False)

                # Blob Service Clientを作成
                blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

                # コンテナが存在しない場合は作成
                try:
                    blob_service_client.create_container(CONTAINER_NAME)
                except Exception as e:
                    # 既に存在する場合のエラーは無視
                    pass

                # Blob Clientを取得してアップロード
                blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

                blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

            except Exception as e:
                st.error(f"データの保存中にエラーが発生しました: {e}")

        save_to_blob(user_data)