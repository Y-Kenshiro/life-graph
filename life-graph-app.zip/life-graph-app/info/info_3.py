import streamlit as st
import pandas as pd
import json
import os
from azure.storage.blob import BlobServiceClient
import time

# --- 質問項目データ ---
# TIPI-Jの日本語版を想定した質問リスト
pvq = [
    {"question": "ある人は、自分なりの意見を形作ることを大事にしている。"},
    {"question": "ある人は、自分の国が安全で安定していることを大事にしている。"},
    {"question": "ある人は、楽しい時間を過ごすことを大事にしている。"},
    {"question": "ある人は、人を困らせないことを大事にしている。"},
    {"question": "ある人は、社会の中で弱く傷つきやすい人々が守られることを大事にしている。"},
    {"question": "ある人は、自分が言った通りに人が動くことを大事にしている。"},
    {"question": "ある人は、自分が他の人より価値があるとは決して考えないことを大事にしている。"},
    {"question": "ある人は、自然を大切にすることを大事にしている。"},
    {"question": "ある人は、誰にも恥をかかされないことを大事にしている。"},
    {"question": "ある人は、いつも何か新しくやる事を探すことを大事にしている。"},
    {"question": "ある人は、親しい人の世話をすることを大事にしている。"},
    {"question": "ある人は、お金がもたらす権力を手に入れることを大事にしている。"},
    {"question": "ある人は、病気を避け、健康を守ることをとても大事にしている。"},
    {"question": "ある人は、あらゆる人達や集団に対して寛容であることを大事にしている。"},
    {"question": "ある人は、規則や規定を決して破らないことを大事にしている。"},
    {"question": "ある人は、自分の人生は自分で決断するということを大事にしている。"},
    {"question": "ある人は、人生において野心をもつことを大事にしている。"},
    {"question": "ある人は、伝統的な価値観や物の考え方を持ち続けることを大事にしている。"},
    {"question": "ある人は、知り合いから絶対の信頼を置かれることを大事にしている。"},
    {"question": "ある人は、裕福であることを大事にしている。"},
    {"question": "ある人は、自然を守るための活動に参加することを大事にしている。"},
    {"question": "ある人は、人を決して苛立たせないことを大事にしている。"},
    {"question": "ある人は、自分の考えを確立することを大事にしている 。"},
    {"question": "ある人は、世間体を守り続けることを大事にしている。"},
    {"question": "ある人は、自分の大切な人を助けることをとても大事にしている。"},
    {"question": "ある人は、自分の身が安全で守られていることを大事にしている。"},
    {"question": "ある人は、信頼され、頼られる友人となることを大事にしている。"},
    {"question": "ある人は、人生を刺激的にするようなリスクを負うことを大事にしている 。"},
    {"question": "ある人は、自分の望むことを他の人にさせる権力をもつことを大事にしている。"},
    {"question": "ある人は、自立して行動を計画することを大事にしている。"},
    {"question": "ある人は、誰も見ていない時でも規則を守ることを大事にしている。"},
    {"question": "ある人は、大きな成功を収めることを大事にしている。"},
    {"question": "ある人は、家族の習慣や宗教のしきたりに従うことを大事にしている。"},
    {"question": "ある人は、自分とは違う人の言うことに耳を傾け、理解する事を大事にしている。"},
    {"question": "ある人は、市民を守ることができる強い国に住むことを大事にしている。"},
    {"question": "ある人は、人生の喜びを味わうことを大事にしている。"},
    {"question": "ある人は、世界のすべての人々が人生において平等な機会をもつことを大事にしている。"},
    {"question": "ある人は、謙虚であることを大事にしている。"},
    {"question": "ある人は、物事を自分で何とかすることを大事にしている。"},
    {"question": "ある人は、自身の文化に関する伝統的なしきたりを重んじることを大事にしている。"},
    {"question": "ある人は、周囲の人にやるべきことを指示する立場であることを大事にしている。"},
    {"question": "ある人は、いかなる法律も遵守することを大事にしている 。"},
    {"question": "ある人は、あらゆる種類の新しい経験をすることを大事にしている。"},
    {"question": "ある人は、自分の富が分かる高価なものをもつことを大事にしている。"},
    {"question": "ある人は、自然環境を破壊や汚染から守ることを大事にしている。"},
    {"question": "ある人は、あらゆる機会を利用して楽しむことを大事にしている。"},
    {"question": "ある人は、自分の大切な人が必要とする全てのことに携わることを大事にしている 。"},
    {"question": "ある人は、自分の功績を人々が認めることを大事にしている。"},
    {"question": "ある人は、決して屈辱を与えられないことを大事にしている。"},
    {"question": "ある人は、自分の国がすべての脅威から自国を守ることを大事にしている。"},
    {"question": "ある人は、決して人を怒らせないことを大事にしている。"},
    {"question": "ある人は、たとえ自分の知らない人であっても、誰もが公正に扱われることを大事にしている。"},
    {"question": "ある人は、いかなる危険も避けることを大事にしている。"},
    {"question": "ある人は、今あるものに満足し、それ以上を求めないことを大事にしている。"},
    {"question": "ある人は、すべての友人や家族が自分に絶対の信頼を寄せられることを大事にしている。"},
    {"question": "ある人は、やることを自分で自由に選択できることを大事にしている。"},
    {"question": "ある人は、たとえ自分と意見が反対の立場の人であっても、その人を受け入れることを大事にしている。"}
]

assessment=pvq
# --- ページ設定とセッション状態の初期化 ---
st.set_page_config(page_title="Schwartzによる10の価値観に基づくテスト", layout="wide")

# 'answers', 'survey_completed', 'current_page' を初期化
if 'answers' not in st.session_state:
    st.session_state.answers = {}
pvq = st.session_state.user_data.get("pvq", None)
if pvq != None:
    for i, item in enumerate(pvq):
        st.session_state.answers[f"q_{i}"] = item["rating"]
if 'survey_completed' not in st.session_state:
    st.session_state.survey_completed = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = 0

# --- 定数とヘルパーテキスト ---
QUESTIONS_PER_PAGE = 10
TOTAL_QUESTIONS = len(assessment)
TOTAL_PAGES = (TOTAL_QUESTIONS + QUESTIONS_PER_PAGE - 1) // QUESTIONS_PER_PAGE
OPTIONS_LABELS = {
    1: "全く似ていない",
    2: "似ていない",
    3: "少しだけ似ている",
    4: "ある程度似ている",
    5: "似ている",
    6: "とてもよく似ている"
}

# --- ラジオボタンのレイアウトを調整するCSS ---
st.markdown("""
<style>
/* 各質問行のスペースを縮める */
.question-row {
    margin-bottom: 0.3rem !important;
    padding-bottom: 0 !important;
}
/* デフォルトの水平線のスペースを縮める */
hr {
    margin: 0.3rem 0 !important;
}
</style>
""", unsafe_allow_html=True)

st.title("Schwartzによる10の価値観に基づくテスト")
st.info("以下では、さまざまな人達について簡単に述べています。それぞれの記述を読んで、その人がどのくらいあなたに似ているかを1から6までの数字のうちもっとも適切なものを選んでください。")

def main_pvq():
    # --- アンケート完了後の画面 ---
    if st.session_state.survey_completed:
        st.success("ご協力ありがとうございました!すべての質問への回答が完了しました。")
        st.balloons()

        # 回答データを整形
        final_answers = []
        for i, item in enumerate(assessment):
            final_answers.append({
                "question": item["question"],
                "rating": st.session_state.answers.get(f"q_{i}")
            })

        st.session_state.user_data["pvq"] = final_answers

        #st.write("あなたの回答:")
        #st.dataframe(pd.DataFrame(final_answers)[["question","rating"]], width="stretch")

        if st.button("終了する"):
            st.session_state.role = "Check"
            st.session_state.survey_completed = False # 次回のためにリセット
            st.session_state.current_page = 0 # 次回のためにリセット
            st.session_state.user_data["test_end"]= time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            st.rerun()

    # --- アンケート中の画面 ---
    else:
        # 現在のページ番号を取得
        page = st.session_state.current_page

        # 進捗状況を表示
        st.info(f"質問グループ {page + 1}/{TOTAL_PAGES}")
        st.progress((page + 1) / TOTAL_PAGES)
        st.markdown("---")

        # グリッドのヘッダーを作成
        header_cols = st.columns([5, 4])
        with header_cols[0]:
            st.markdown("**質問項目**")
        with header_cols[1]:
            # ヘッダー用の列を作成
            sub_cols = st.columns(7)
            for i, label in OPTIONS_LABELS.items():
                sub_cols[i-1].markdown(
                    f"<div style='text-align: center;'><b>{i}</b><br>{label}</div>",
                    unsafe_allow_html=True
                )

        # 表示する質問の範囲を計算
        start_idx = page * QUESTIONS_PER_PAGE
        end_idx = min(start_idx + QUESTIONS_PER_PAGE, TOTAL_QUESTIONS)

        # 質問を表示
        for i in range(start_idx, end_idx):
            item = assessment[i]
            q_key = f"q_{i}"
            row_cols = st.columns([5, 4])
            with row_cols[0]:
                st.markdown(f"<div class='question-row'><b>{i+1}.</b> {item['question']}</div>", unsafe_allow_html=True)

            with row_cols[1]:
                #sub_cols = st.columns(7)
                #for j, score in enumerate(OPTIONS_LABELS.keys()):
                    #with sub_cols[j]:
                answer = st.radio(
                    "評価を選択してください",
                    options=OPTIONS_LABELS.keys(),
                    key=f"{q_key}_{OPTIONS_LABELS.keys()}",
                    horizontal=True,
                    label_visibility="collapsed",
                    index=list(OPTIONS_LABELS.keys()).index(st.session_state.answers[q_key]) if q_key in st.session_state.answers else None
                )
                # 回答を即座に保存
                if answer is not None:
                    st.session_state.answers[q_key] = answer
            st.markdown("---")

        # --- ページネーションボタン ---
        # 現在のページの質問にすべて回答したかチェック
        current_questions_keys = [f"q_{i}" for i in range(start_idx, end_idx)]
        all_answered_on_page = all(key in st.session_state.answers for key in current_questions_keys)

        # 「次へ」または「送信」ボタン
        if page < TOTAL_PAGES - 1:
            if st.button("次へ", width="stretch", disabled=not all_answered_on_page):
                st.session_state.current_page += 1
                st.rerun()
        else:
            if st.button("回答を送信する", type="primary", width="stretch", disabled=not all_answered_on_page):
                st.session_state.survey_completed = True
                st.rerun()

        if not all_answered_on_page:
            st.warning("このページのすべての質問に回答すると、次に進めます。")

if __name__ == "__main__":
    try:
        main_pvq()
    except Exception as e:
        st.error(f"エラーが発生しました。ご迷惑をおかけします。{e}")
        st.info("再度同じユーザーIDを入力すると、進捗を復元できます。")

        user_data = {}
        user_data["user_id"] = st.session_state.user_data.get("user_id", "")
        user_data["gender"] = st.session_state.user_data.get("gender", "")
        user_data["age"] = st.session_state.user_data.get("age", "未回答")
        user_data["job"] = st.session_state.user_data.get("job", "未回答")
        user_data["tipi"] = st.session_state.user_data.get("tipi", None)
        user_data["pvq"] = st.session_state.user_data.get("pvq", None)
        user_data["life"] = st.session_state.user_data.get("life", None)
        user_data["error_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

        # --- Azure Blob Storage 接続情報 ---
        # 環境変数から接続文字列とコンテナ名を取得
        # これらは後ほどAzureの画面で設定します
        CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
        CONTAINER_NAME = "results" # 作成するコンテナ名

        def save_to_blob(data):
            """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
            if not CONNECT_STR:
                st.error("Azureの接続文字列が設定されていません。")
                return

            try:
                file_name = f"survey_result_{user_data['user_id']}.json"

                # JSONデータに変換
                json_data = json.dumps(data, indent=2, ensure_ascii=False)

                # Blob Service Clientを作成
                blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

                # コンテナが存在しない場合は作成
                try:
                    blob_service_client.create_container(CONTAINER_NAME)
                except Exception as e:
                    # 既に存在する場合のエラーは無視
                    pass

                # Blob Clientを取得してアップロード
                blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

                blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

            except Exception as e:
                st.error(f"データの保存中にエラーが発生しました: {e}")

        save_to_blob(user_data)