import streamlit as st
import pandas as pd
import json
import os
from azure.storage.blob import BlobServiceClient

# --- 質問項目データ ---
# 1ユーロ = 180円で換算（端数があると読解しにくいため、為替レート177円を四捨五入した）
emcs = [
    {
        "key": "2",
        "question": "仕事に出かけようとしていたところ、近所に住む友人が私の家のインターホンを鳴らしました。友人は、体調が悪いので病院まで車で連れて行ってもらえないかと頼んできました。私はすでに仕事に遅れていて、今日は上司との会議があります。どうすればいいでしょうか？",
        "altruistic": "友人を病院へ連れていく",
        "egoistic": "仕事に行く"
    },
    {
        "key": "5",
        "question": "私の友人の一人が、友人の大好きな古いコンピューターゲームをぜひ私から買いたいと言っています。私は明日、彼に3,600円で売ると約束しました。しかし、後からインターネットで確認すると、すぐに10,800円で売ることができるとわかりました。私はどうするべきでしょうか？",
        "altruistic": "友人との約束を守る",
        "egoistic": "インターネットでもっと高く売る"
    },
    {
        "key": "7",
        "question": "今夜、妹の子どもたちの世話をすることを約束しました。しかし、今になって、今夜は私にとって非常に重要な送別会にも招待されていることに気付きました。パーティーに行く口実を考えることもできます。どうすればよいでしょうか？",
        "altruistic": "妹との約束を守る",
        "egoistic": "パーティーに行く口実を考える"
    },
    {
        "key": "8",
        "question": "友人がコインコレクションを相続しました。私はそのコインコレクションに非常に興味を持っています。友人はそのコインを私に安い価格で売ることを提案しています。しかし、そのコインは収集家にとって非常に価値があるもので、実際にかなり高額な価値があります。私はどうすべきでしょうか？",
        "altruistic": "友人にその価値を知らせる",
        "egoistic": "そのコインを安い価格で購入する"
    },
    {
        "key": "9",
        "question": "私と友人はあるバンドの大ファンです。そのバンドが私たちの故郷でコンサートを開くことになり、私たちは二人とも行きたいと思っています。チケット代理店で、私は1枚しかチケットを手に入れることができません。どうすればいいでしょうか？",
        "altruistic": "友人にチケットをあげる",
        "egoistic": "自分がコンサートに行く"
    },
    {
        "key": "10",
        "question": "自転車を施錠しているときに、車にぶつかってしまいました。暗くて、車に傷がついているかはわかりませんでした。翌日、よく知っている隣人が新しい車に新しい傷がついたと文句を言っているのを聞きました。どうすればよいですか？",
        "altruistic": "昨日のことについて隣人に知らせる",
        "egoistic": "黙っておく"
    },
    {
        "key": "11",
        "question": "今日はサッカーワールドカップの決勝戦がテレビで放送されています。私は大のサッカーファンで、試合にとても興奮しています。突然、体調の優れない友人から電話があり、今すぐ会いたいと言われました。私はどうすればいいでしょうか？",
        "altruistic": "友人と会う",
        "egoistic": "サッカーの試合を観る"
    },
    {
        "key": "12",
        "question": "私は、パートナーと一緒に会社のパーティーに行くことを約束しました。パートナーはすでに私たち二人で申し込みをしています。しかし、今になって重要な試験に向けた準備の時間がどうしても必要だと気付きました。どうすればいいでしょうか？",
        "altruistic": "約束を守る",
        "egoistic": "試験の準備をする"
    },
    {
        "key": "16",
        "question": "私は空港にいて、長い間計画していた休暇に出発する準備をしています。チェックインカウンターに立っていると、母から電話がかかってきます。母は父が軽い事故に遭い、入院したことを教えてくれます。私はどうすればいいでしょうか？",
        "altruistic": "休暇をキャンセルする",
        "egoistic": "それでも飛行機に乗る"
    },
    {
        "key": "20",
        "question": "私は今日の午後、祖母を病院に連れて行くと約束しています。しかし、予約の1時間前に上司から電話があり、緊急で重要な会議に呼ばれました。この会議は私の昇進についてのものです。私はどうすればいいでしょうか？",
        "altruistic": "祖母を病院に連れていく",
        "egoistic": "上司と会議に向かう"
    },
    {
        "key": "24",
        "question": "私は、休暇中にカクテルバーを訪れました。支払いをお願いすると、ウェイターが請求書を持ってきます。それを見ていると、最後のカクテルの分が請求されていないことに気付きました。どうしますか？",
        "altruistic": "間違いを指摘する",
        "egoistic": "最後のカクテル抜きの代金を払う"
    },
    {
        "key": "26",
        "question": "私は古い車を売りたいです。その車のラジエーターは実際には緊急に交換する必要があることを知っています。ラジエーターの問題に気づかない男性が、すぐに現金で高額を支払うと言っています。私はどうすべきでしょうか？",
        "altruistic": "問題について伝える",
        "egoistic": "黙っておく"
    },
    {
        "key": "27",
        "question": "私は今、スーパーマーケットの駐車場で車に乗ろうとしています。隣で、女性の買い物袋が破れて、彼女の購入品がすべて地面に落ちてしまいます。もし私がその女性を助ければ、大事な約束に遅れてしまいます。どうしますか？",
        "altruistic": "女性を助ける",
        "egoistic": "車に乗る。"
    },
    {
        "key": "30",
        "question": "私はスーパーマーケットのレジにいて、1,440円の食料品の支払いをしたいです。私は1,800円紙幣をレジ係に渡します。彼女は誤って360円ではなく720円のお釣りを渡しました。私はどうしますか？",
        "altruistic": "お金を返す",
        "egoistic": "そのまま受け取る"
    },
    {
        "key": "31",
        "question": "私は、まもなく出発する一時間に一度しか運行しないバスに間に合うように走っています。目の前で、二人の小さな子供がいる女性のバッグからいくつかの物が落ちます。私以外に、女性を助けられる人は周りにいません。私はどうすればいいでしょうか？",
        "altruistic": "女性を助ける",
        "egoistic": "バスに向かって走る"
    },
    {
        "key": "35",
        "question": "フリーマーケットで絵を売りたいです。女性が18,000円で購入したいと言い、私は同意します。その女性が現金を引き出すために銀行に向かう途中、別の人がその絵に27,000円を支払いたいと言います。どうすればいいですか？",
        "altruistic": "最初の女性に売る",
        "egoistic": "高い金額を提案した人に売る"
    },
    {
        "key": "37",
        "question": "ある晩、通りで財布を見つけました。中には9,000円入っていますが、身分証明書などの個人情報は何もありません。持ち主を突き止める方法はありません。しかし、市の遺失物取扱所に財布を届けることはできます。私はどうすべきでしょうか？",
        "altruistic": "財布を届ける",
        "egoistic": "持っておく"
    },
    {
        "key": "38",
        "question": "私は重要なビジネス会議に車で向かっており、今日は少し遅れています。目の前で、軽い追突事故が起こります。もし車を止めたら、おそらく会議に遅れてしまいます。どうしますか？",
        "altruistic": "車を止める",
        "egoistic": "運転を続ける"
    },
    {
        "key": "39",
        "question": "大事な用事に間に合うように家に帰るために、私は絶対にバスに乗りたいです。バスが出発する直前に、歩行者用信号が赤になります。交差点の向こう側に小さな男の子が立っています。私はどうしますか？",
        "altruistic": "青信号になるのを待つ",
        "egoistic": "赤信号で交差点を渡る"
    },
    {
        "key": "40",
        "question": "電車で家に帰りたいです。電車に乗ろうとすると、松葉杖を使った男性が階段でスーツケースをうまく運べずにいるのが見えます。もしその男性を助けたら、電車に乗り遅れてしまいます。どうしますか？",
        "altruistic": "男性を助ける",
        "egoistic": "電車に乗る"
    }
]

assessment=emcs
# --- ページ設定とセッション状態の初期化 ---
st.set_page_config(page_title="選択テスト", layout="wide")

# 'answers', 'survey_completed', 'current_page' を初期化
if 'emcs_answers' not in st.session_state:
    st.session_state.emcs_answers = {}
    emcs = st.session_state.user_data.get("emcs")
    if emcs != None:
        for i, item in enumerate(emcs):
            st.session_state.emcs_answers[f"q_{i}"] = item["rating"]
            st.session_state.emcs_answers[f"reason_{i}"] = item["reason"]

if 'survey_completed' not in st.session_state:
    st.session_state.survey_completed = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = 0

# --- 定数とヘルパーテキスト ---
QUESTIONS_PER_PAGE = 5
TOTAL_QUESTIONS = len(assessment)
TOTAL_PAGES = (TOTAL_QUESTIONS + QUESTIONS_PER_PAGE - 1) // QUESTIONS_PER_PAGE

# --- ラジオボタンのレイアウトを調整するCSS ---
st.markdown("""
<style>
/* ラジオボタンのコンテナをFlexboxにして、中身を均等に配置 */
div[role="radiogroup"] > div {
    display: flex;
    justify-content: space-between;
    width: 100%;
}
</style>
""", unsafe_allow_html=True)

st.title("EMCSを用いた行動選択テスト")
st.info("""以下の質問に回答してください。
        質問に正解はありません。あなたが直感的に選びたいと思う方を選んでください。""")

def main_emcs():
    # --- アンケート完了後の画面 ---
    if st.session_state.survey_completed:
        st.success("ご協力ありがとうございました!すべての質問への回答が完了しました。")
        st.balloons()

        # 回答データを整形
        final_answers = []
        for i, item in enumerate(assessment):
            final_answers.append({
                "question": item["question"],
                "rating": st.session_state.emcs_answers.get(f"q_{i}"),
                "reason": st.session_state.emcs_answers.get(f"reason_{i}", "")
            })

        st.session_state.user_data["emcs"] = final_answers

        #st.write("あなたの回答:")
        #st.dataframe(pd.DataFrame(final_answers)[["question","rating"]], width="stretch")

        if st.button("終了する"):
            st.session_state.role = "Check"
            st.session_state.survey_completed = False # 次回のためにリセット
            st.session_state.current_page = 0
            st.rerun()

    # --- アンケート中の画面 ---
    else:
        # 現在のページ番号を取得
        page = st.session_state.current_page

        # 進捗状況を表示
        st.info(f"質問グループ {page + 1}/{TOTAL_PAGES}")
        st.progress((page + 1) / TOTAL_PAGES)
        st.markdown("---")

        # グリッドのヘッダーを作成
        header_cols = st.columns([4, 5])
        with header_cols[0]:
            st.markdown("**質問項目**")
        #with header_cols[1]:
            # ヘッダー用の列を作成
            #sub_cols = st.columns(5)
            #for i, label in OPTIONS_LABELS.items():
            #    sub_cols[i-1].markdown(f"<div style='text-align: center;'><b>{i}</b></div>", unsafe_allow_html=True)

        st.markdown("<hr style='margin-top: 0; margin-bottom: 1rem;'>", unsafe_allow_html=True)

        # 表示する質問の範囲を計算
        start_idx = page * QUESTIONS_PER_PAGE
        end_idx = min(start_idx + QUESTIONS_PER_PAGE, TOTAL_QUESTIONS)

        # 質問を表示
        for i in range(start_idx, end_idx):
            item = assessment[i]
            OPTIONS_LABELS = {item["altruistic"]:1, item["egoistic"]:2}
            q_key = f"q_{i}"
            reason_key = f"reason_{i}"
            row_cols = st.columns([4, 5])
            with row_cols[0]:
                st.markdown(f"**{i+1}.** {item['question']}")

            with row_cols[1]:
                # st.radioは横幅いっぱいに広がるため、右側の列全体に配置
                answer = st.radio(
                    label="選択肢",
                    options=list(OPTIONS_LABELS.keys()),
                    key=q_key,
                    horizontal=True,
                    index=None,
                    label_visibility="hidden"
                )
                reason = st.text_area(
                    "選んだ理由や重要視した点を教えてください。簡単で構いません。",
                    key=reason_key,
                    placeholder=
                    """例： 〇〇な理由でこちらを選びました。
    例： もし〇〇なら逆の選択をしたけど、今回は〇〇ということだったのでこっちを選んだ。""",
                    value=st.session_state.emcs_answers[reason_key] if reason_key in st.session_state.emcs_answers else ""
                )
                # 回答を即座に保存
                if answer is not None:
                    st.session_state.emcs_answers[q_key] = answer
                    st.session_state.emcs_answers[reason_key] = reason

        st.markdown("---")

        # --- ページネーションボタン ---
        # 現在のページの質問にすべて回答したかチェック
        current_questions_keys = [f"q_{i}" for i in range(start_idx, end_idx)]
        all_answered_on_page = all(key in st.session_state.emcs_answers for key in current_questions_keys)

        # 「次へ」または「送信」ボタン
        if page < TOTAL_PAGES - 1:
            if st.button("次へ", width="stretch", disabled=not all_answered_on_page):
                st.session_state.current_page += 1
                st.rerun()
        else:
            if st.button("回答を送信する", type="primary", width="stretch", disabled=not all_answered_on_page):
                st.session_state.survey_completed = True
                st.rerun()

        if not all_answered_on_page:
            st.warning("このページのすべての質問に回答すると、次に進めます。")

if __name__ == "__main__":
    try:
        main_emcs()
    except Exception as e:
        st.error(f"エラーが発生しました。ご迷惑をおかけします。")
        st.info("再度同じユーザーIDを入力すると、進捗を復元できます。")

        user_data = {}
        user_data["user_id"] = st.session_state.user_data.get("user_id", "")
        user_data["gender"] = st.session_state.user_data.get("gender", "")
        user_data["age"] = st.session_state.user_data.get("age", "未回答")
        user_data["job"] = st.session_state.user_data.get("job", "未回答")
        user_data["bfi"] = st.session_state.user_data.get("bfi", None)
        user_data["emcs"] = st.session_state.user_data.get("emcs", None)
        user_data["life"] = st.session_state.user_data.get("life", None)

        # --- Azure Blob Storage 接続情報 ---
        # 環境変数から接続文字列とコンテナ名を取得
        # これらは後ほどAzureの画面で設定します
        CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
        CONTAINER_NAME = "results" # 作成するコンテナ名

        def save_to_blob(data):
            """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
            if not CONNECT_STR:
                st.error("Azureの接続文字列が設定されていません。")
                return

            try:
                file_name = f"survey_result_{user_data['user_id']}.json"

                # JSONデータに変換
                json_data = json.dumps(data, indent=2, ensure_ascii=False)

                # Blob Service Clientを作成
                blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

                # コンテナが存在しない場合は作成
                try:
                    blob_service_client.create_container(CONTAINER_NAME)
                except Exception as e:
                    # 既に存在する場合のエラーは無視
                    pass

                # Blob Clientを取得してアップロード
                blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

                blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

                st.success(f"回答が正常に保存されました！ ブラウザを閉じても大丈夫です")

            except Exception as e:
                st.error(f"データの保存中にエラーが発生しました: {e}")

        save_to_blob(user_data)