import streamlit as st
import time
import json
import os
from azure.storage.blob import BlobServiceClient

# --- 質問項目データ ---
# TIPI-Jの日本語版を想定した質問リスト
tipi = [
    {"question": "活発で、外向的だと思う"},
    {"question": "他人に不満をもち、もめごとを起こしやすいと思う"},
    {"question": "しっかりしていて、自分に厳しいと思う"},
    {"question": "心配性で、うろたえやすいと思う"},
    {"question": "新しいことが好きで、変わった考えをもつと思う"},
    {"question": "ひかえめで、おとなしいと思う"},
    {"question": "人に気をつかう、やさしい人間だと思う"},
    {"question": "だらしなく、うっかりしていると思う"},
    {"question": "冷静で、気分が安定していると思う"},
    {"question": "発想力に欠けた、平凡な人間だと思う"}
]

assessment=tipi
# --- ページ設定とセッション状態の初期化 ---
st.session_state.user_data["test_start"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
st.set_page_config(page_title="日本語版Ten Item Personality Inventoryテスト", layout="wide")

# 'answers', 'survey_completed', 'current_page' を初期化
if 'answers' not in st.session_state:
    st.session_state.answers = {}
tipi = st.session_state.user_data.get("tipi", None)
if tipi != None:
    for i, item in enumerate(tipi):
        st.session_state.answers[f"q_{i}"] = item["rating"]
if 'survey_completed' not in st.session_state:
    st.session_state.survey_completed = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = 0

# --- 定数とヘルパーテキスト ---
OPTIONS_LABELS = {
    1: "全く違うと思う",
    2: "おおよそ違うと思う",
    3: "少し違うと思う",
    4: "どちらでもない",
    5: "少しそう思う",
    6: "まあまあそう思う",
    7: "強くそう思う"
}

# --- ラジオボタンのレイアウトを調整するCSS ---
st.markdown("""
<style>
/* 各質問行のスペースを縮める */
.question-row {
    margin-bottom: 0.3rem !important;
    padding-bottom: 0 !important;
}
/* デフォルトの水平線のスペースを縮める */
hr {
    margin: 0.3rem 0 !important;
}
</style>
""", unsafe_allow_html=True)

st.title("BigFiveInventoryを用いた性格診断")
st.info("""1から10までのことばがあなた自身にどのくらい当てはまるかについて，1から7までの数字のうちもっとも適切なものを選んでください。文章全体を総合的に見て，自分にどれだけ当てはまるかを評価してください。""")

def main_tipi():
    # --- アンケート完了後の画面 ---
    if st.session_state.survey_completed:
        st.success("ご回答ありがとうございます！次のテストにお進みください")

        # 回答データを整形
        final_answers = []
        for i, item in enumerate(assessment):
            final_answers.append({
                "question": item["question"],
                "rating": st.session_state.answers.get(f"q_{i}")
            })

        st.session_state.user_data["tipi"] = final_answers

        #st.write("あなたの回答:")
        #st.dataframe(pd.DataFrame(final_answers)[["question","rating"]], width="stretch")

        if st.button("次へ"):
            st.session_state.role = "Info3"
            st.session_state.answers = {} # 次回のためにリセット
            st.session_state.survey_completed = False # 次回のためにリセット
            st.session_state.current_page = 0 # 次回のためにリセット
            st.rerun()

    # --- アンケート中の画面 ---
    else:
        # ヘッダーを作成
        header_cols = st.columns([5, 4])
        with header_cols[0]:
            st.markdown("**質問項目**")
        with header_cols[1]:
            # ヘッダー用の列を作成
            sub_cols = st.columns(7)
            for i, label in OPTIONS_LABELS.items():
                sub_cols[i-1].markdown(
                    f"<div style='text-align: center;'><b>{i}</b><br>{label}</div>",
                    unsafe_allow_html=True
                )
        st.markdown("---")

        # 質問を表示
        for i in range(len(assessment)):
            item = assessment[i]
            q_key = f"q_{i}"
            row_cols = st.columns([5, 4])
            with row_cols[0]:
                st.markdown(f"<div class='question-row'><b>{i+1}.</b> {item['question']}</div>", unsafe_allow_html=True)

            with row_cols[1]:
                #sub_cols = st.columns(7)
                #for j, score in enumerate(OPTIONS_LABELS.keys()):
                    #with sub_cols[j]:
                answer = st.radio(
                    "評価を選択してください",
                    options=OPTIONS_LABELS.keys(),
                    key=f"{q_key}_{OPTIONS_LABELS.keys()}",
                    horizontal=True,
                    label_visibility="collapsed",
                    index=list(OPTIONS_LABELS.keys()).index(st.session_state.answers[q_key]) if q_key in st.session_state.answers else None,
                )
                # 回答を即座に保存
                if answer is not None:
                    st.session_state.answers[q_key] = answer
            st.markdown("---")

        # --- ページネーションボタン ---
        # 現在のページの質問にすべて回答したかチェック
        current_questions_keys = [f"q_{i}" for i in range(len(assessment))]
        all_answered_on_page = all(key in st.session_state.answers for key in current_questions_keys)

        # 「次へ」または「送信」ボタン
        if st.button("回答を送信する", type="primary", width="stretch", disabled=not all_answered_on_page):
            st.session_state.survey_completed = True
            st.rerun()

if __name__ == "__main__":
    try:
        main_tipi()
    except Exception as e:
        st.error(f"エラーが発生しました。ご迷惑をおかけします。: {e}")
        st.info("再度同じユーザーIDを入力すると、進捗を復元できます。")

        user_data = {}
        user_data["user_id"] = st.session_state.user_data.get("user_id", "")
        user_data["gender"] = st.session_state.user_data.get("gender", "")
        user_data["age"] = st.session_state.user_data.get("age", "未回答")
        user_data["job"] = st.session_state.user_data.get("job", "未回答")
        user_data["tipi"] = st.session_state.user_data.get("tipi", None)
        user_data["pvq"] = st.session_state.user_data.get("pvq", None)
        user_data["life"] = st.session_state.user_data.get("life", None)
        user_data["error_time"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

        # --- Azure Blob Storage 接続情報 ---
        # 環境変数から接続文字列とコンテナ名を取得
        # これらは後ほどAzureの画面で設定します
        CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
        CONTAINER_NAME = "results" # 作成するコンテナ名

        def save_to_blob(data):
            """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
            if not CONNECT_STR:
                st.error("Azureの接続文字列が設定されていません。")
                return

            try:
                file_name = f"survey_result_{user_data['user_id']}.json"

                # JSONデータに変換
                json_data = json.dumps(data, indent=2, ensure_ascii=False)

                # Blob Service Clientを作成
                blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

                # コンテナが存在しない場合は作成
                try:
                    blob_service_client.create_container(CONTAINER_NAME)
                except Exception as e:
                    # 既に存在する場合のエラーは無視
                    pass

                # Blob Clientを取得してアップロード
                blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

                blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

            except Exception as e:
                st.error(f"データの保存中にエラーが発生しました: {e}")

        save_to_blob(user_data)