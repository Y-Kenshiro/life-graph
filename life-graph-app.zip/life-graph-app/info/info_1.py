import streamlit as st
import os
import json
from azure.storage.blob import BlobServiceClient
from azure.core.exceptions import ResourceNotFoundError
import time

info = {}
if 'info_completed' not in st.session_state:
    st.session_state.info_completed = False

st.title("アンケート")
st.info("""以下のアンケートに答えてください。""")

# --- Azureからデータを読み込む関数 (★新規追加) ---
def load_state_from_azure(connection_string, container_name, user_id):
    """
    Azureから保存された状態を読み込み、session_stateに復元する。
    """
    try:
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        blob_name = f"survey_result_{user_id}.json" # 保存時と同じファイル名ルール
        blob_client = blob_service_client.get_blob_client(container=container_name, blob=blob_name)

        # ファイルをダウンロードして内容を読み込む
        downloader = blob_client.download_blob()
        saved_state_json = downloader.readall()

        # JSON文字列をPythonの辞書に変換
        saved_state = json.loads(saved_state_json)

        # 読み込んだデータでsession_stateを更新
        for key, value in saved_state.items():
            st.session_state.user_data[key] = value

        st.success("前回の回答データを復元しました。")
        st.session_state.user_data["error_fixed"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        print(f"'{blob_name}' からデータを正常に読み込みました。")

    except ResourceNotFoundError:
        # ファイルが見つからない場合は、何もしない（初回アクセス）
        st.success("ご回答ありがとうございます。次へお進みください")
        st.session_state.user_data["user_id"] = info["ユーザーID"]
        st.session_state.user_data["gender"] = info["性別"]
        st.session_state.user_data["age"] = info["年齢"]
        st.session_state.user_data["job"] = info["職業"]
    except Exception as e:
        # その他のエラーが発生した場合
        st.error(f"データの読み込み中にエラーが発生しました: {e}")
        print(f"データの読み込み中にエラー: {e}")


if not st.session_state.info_completed:
    info["ユーザーID"] = st.text_input(
        "ユーザーID(半角で答えてください)",
        value="",
        placeholder="ユーザーID(半角)",
    )
    info["性別"] = st.radio(
        "性別",
        ["男性", "女性", "未回答"],
        index=None
    )

    info["年齢"] = st.number_input(
        "年齢(半角で答えてください)",
        value=None,
        placeholder="例: 20",
        step=1
    )

    info["職業"] = st.text_input(
        "職業",
        value="",
        placeholder="例: 学生、会社員、主婦など",
        max_chars=50
    )

    if st.button("回答完了", disabled=info["ユーザーID"]=="" or info["性別"]=="" or info["年齢"] is None or info["職業"]==""):
        comp = True
        user_id=info["ユーザーID"].strip()
        try:
            # Azure接続情報を設定
            CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
            CONTAINER_NAME = "results"
            load_state_from_azure(CONNECT_STR, CONTAINER_NAME, user_id)
        except Exception as e:
            st.session_state.user_data["user_id"] = info["ユーザーID"]
            st.session_state.user_data["gender"] = info["性別"]
            st.session_state.user_data["age"] = info["年齢"]
            st.session_state.user_data["job"] = info["職業"]
        st.session_state.info_completed = True

if st.session_state.info_completed:
    if st.button("次へ"):
        st.session_state.role = "Graph"
        st.session_state.user_data["graph_start"]= time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        st.rerun()