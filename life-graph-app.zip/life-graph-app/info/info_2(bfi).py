import streamlit as st
import pandas as pd
import json
import os
from azure.storage.blob import BlobServiceClient

# --- 質問項目データ ---
# BFI-60の日本語版を想定した質問リスト
bfi30 = [
    {"question": "無口な方だ", "domain": "外向性", "facet": "社交性", "reverse": True},
    {"question": "思いやりがあり，優しい", "domain": "協調性", "facet": "思いやり", "reverse": False},
    {"question": "行き当たりばったりな方だ", "domain": "勤勉性", "facet": "秩序", "reverse": True},
    {"question": "多くの悩みごとを抱えている", "domain": "否定的情動性", "facet": "不安", "reverse": False},
    {"question": "芸術，音楽，文学に魅了されている", "domain": "開放性", "facet": "美的感性", "reverse": False},
    {"question": "上に立つ方で，リーダーとして活動する", "domain": "外向性", "facet": "自己主張性", "reverse": False},
    {"question": "他人を見下すことがある", "domain": "協調性", "facet": "敬意", "reverse": True},
    {"question": "なかなか作業に取り掛かることができない", "domain": "勤勉性", "facet": "生産性", "reverse": True},
    {"question": "憂うつになり，落胆する方だ", "domain": "否定的情動性", "facet": "抑うつ", "reverse": False},
    {"question": "抽象的な知識にはほとんど関心がない", "domain": "開放性", "facet": "知的好奇心", "reverse": True},
    {"question": "活力にあふれている", "domain": "外向性", "facet": "活力", "reverse": False},
    {"question": "人々のいちばん良いところを思い浮かべる", "domain": "協調性", "facet": "信用", "reverse": False},
    {"question": "ちゃんとしていて，いつも周りから当てにされる", "domain": "勤勉性", "facet": "責任感", "reverse": False},
    {"question": "情緒が安定しており，簡単には取り乱さない", "domain": "否定的情動性", "facet": "情緒不安定性", "reverse": True},
    {"question": "個性的で，新しいアイディアを思いつく", "domain": "開放性", "facet": "創造的想像力", "reverse": False},
    {"question": "積極的で，社交的である", "domain": "外向性", "facet": "社交性", "reverse": False},
    {"question": "冷淡で思いやりに欠けることがある", "domain": "協調性", "facet": "思いやり", "reverse": True},
    {"question": "物事をきれいに揃えたりまとめたりする", "domain": "勤勉性", "facet": "秩序", "reverse": False},
    {"question": "リラックスしていて，ストレスにうまく対処している", "domain": "否定的情動性", "facet": "不安", "reverse": True},
    {"question": "芸術的関心があまりない", "domain": "開放性", "facet": "美的感性", "reverse": True},
    {"question": "他の人にリーダーシップを発揮してもらうほうが良いと思う", "domain": "外向性", "facet": "自己主張性", "reverse": True},
    {"question": "礼儀正しく，他人に敬意をもって接する", "domain": "協調性", "facet": "敬意", "reverse": False},
    {"question": "根気強く，与えられた課題が終わるまで取り組む", "domain": "勤勉性", "facet": "生産性", "reverse": False},
    {"question": "安心感を抱いており，心地よい", "domain": "否定的情動性", "facet": "抑うつ", "reverse": True},
    {"question": "考え方が複雑で，深く考える人間だ", "domain": "開放性", "facet": "知的好奇心", "reverse": False},
    {"question": "他の人と比べて活発ではない", "domain": "外向性", "facet": "活力", "reverse": True},
    {"question": "他人の欠点を見つけ出す方だ", "domain": "協調性", "facet": "信用", "reverse": True},
    {"question": "少し不注意なところがある", "domain": "勤勉性", "facet": "責任感", "reverse": True},
    {"question": "神経質で，感情的になりやすい", "domain": "否定的情動性", "facet": "情緒不安定性", "reverse": False},
    {"question": "創造性がほとんどない", "domain": "開放性", "facet": "創造的想像力", "reverse": True}
]

assessment=bfi30
# --- ページ設定とセッション状態の初期化 ---
st.set_page_config(page_title="Big-Five Personality Assessment", layout="wide")

# 'answers', 'survey_completed', 'current_page' を初期化
if 'answers' not in st.session_state:
    st.session_state.answers = {}
    bfi = st.session_state.user_data.get("bfi")
    if bfi != None:
        for i, item in enumerate(bfi):
            st.session_state.answers[f"q_{i}"] = item["rating"]
if 'survey_completed' not in st.session_state:
    st.session_state.survey_completed = False
if 'current_page' not in st.session_state:
    st.session_state.current_page = 0

# --- 定数とヘルパーテキスト ---
QUESTIONS_PER_PAGE = 10
TOTAL_QUESTIONS = len(assessment)
TOTAL_PAGES = (TOTAL_QUESTIONS + QUESTIONS_PER_PAGE - 1) // QUESTIONS_PER_PAGE
OPTIONS_LABELS = {
    1: "全くあてはまらない",
    2: "あてはまらない",
    3: "どちらともいえない",
    4: "あてはまる",
    5: "とてもよくあてはまる"
}

# --- ラジオボタンのレイアウトを調整するCSS ---
st.markdown("""
<style>
/* ラジオボタンのコンテナをFlexboxにして、中身を均等に配置 */
div[role="radiogroup"] > div {
    display: flex;
    justify-content: space-between;
    width: 100%;
}
</style>
""", unsafe_allow_html=True)

st.title("BigFiveInventoryを用いた性格診断")
st.info('以下の質問に直感で回答してください。')

def main_bfi():
    # --- アンケート完了後の画面 ---
    if st.session_state.survey_completed:
        st.success("ご協力ありがとうございました!すべての質問への回答が完了しました。")
        st.balloons()

        # 回答データを整形
        final_answers = []
        for i, item in enumerate(assessment):
            final_answers.append({
                "question": item["question"],
                "domain": item["domain"],
                "facet": item["facet"],
                "rating": st.session_state.answers.get(f"q_{i}")
            })

        st.session_state.user_data["bfi"] = final_answers

        #st.write("あなたの回答:")
        #st.dataframe(pd.DataFrame(final_answers)[["question","rating"]], width="stretch")

        if st.button("次へ"):
            st.session_state.role = "Info3"
            st.session_state.survey_completed = False # 次回のためにリセット
            st.session_state.current_page = 0 # 次回のためにリセット
            st.rerun()

    # --- アンケート中の画面 ---
    else:
        # 現在のページ番号を取得
        page = st.session_state.current_page

        # 進捗状況を表示
        st.info(f"質問グループ {page + 1}/{TOTAL_PAGES}")
        st.progress((page + 1) / TOTAL_PAGES)
        st.markdown("---")

        # グリッドのヘッダーを作成
        header_cols = st.columns([4, 5])
        with header_cols[0]:
            st.markdown("**質問項目**")
        with header_cols[1]:
            # ヘッダー用の列を作成
            sub_cols = st.columns(5)
            for i, label in OPTIONS_LABELS.items():
                sub_cols[i-1].markdown(f"<div style='text-align: center;'><b>{i}</b><br>{label}</div>", unsafe_allow_html=True)

        st.markdown("<hr style='margin-top: 0; margin-bottom: 1rem;'>", unsafe_allow_html=True)

        # 表示する質問の範囲を計算
        start_idx = page * QUESTIONS_PER_PAGE
        end_idx = min(start_idx + QUESTIONS_PER_PAGE, TOTAL_QUESTIONS)

        # 質問を表示
        for i in range(start_idx, end_idx):
            item = assessment[i]
            q_key = f"q_{i}"
            row_cols = st.columns([4, 5])
            with row_cols[0]:
                st.markdown(f"**{i+1}.** {item['question']}")

            with row_cols[1]:
                # st.radioは横幅いっぱいに広がるため、右側の列全体に配置
                answer = st.radio(
                    "評価を選択してください",
                    options=list(OPTIONS_LABELS.keys()),
                    key=q_key,
                    horizontal=True,
                    label_visibility="collapsed",
                    index=list(OPTIONS_LABELS.keys()).index(st.session_state.answers[q_key]) if q_key in st.session_state.answers else None
                )
                # 回答を即座に保存
                if answer is not None:
                    st.session_state.answers[q_key] = answer
            st.markdown("---")

        # --- ページネーションボタン ---
        # 現在のページの質問にすべて回答したかチェック
        current_questions_keys = [f"q_{i}" for i in range(start_idx, end_idx)]
        all_answered_on_page = all(key in st.session_state.answers for key in current_questions_keys)

        # 「次へ」または「送信」ボタン
        if page < TOTAL_PAGES - 1:
            if st.button("次へ", width="stretch", disabled=not all_answered_on_page):
                st.session_state.current_page += 1
                st.rerun()
        else:
            if st.button("回答を送信する", type="primary", width="stretch", disabled=not all_answered_on_page):
                st.session_state.survey_completed = True
                st.rerun()

        if not all_answered_on_page:
            st.warning("このページのすべての質問に回答すると、次に進めます。")

if __name__ == "__main__":
    try:
        main_bfi()
    except Exception as e:
        st.error(f"エラーが発生しました。ご迷惑をおかけします。")
        st.info("再度同じユーザーIDを入力すると、進捗を復元できます。")

        user_data = {}
        user_data["user_id"] = st.session_state.user_data.get("user_id", "")
        user_data["gender"] = st.session_state.user_data.get("gender", "")
        user_data["age"] = st.session_state.user_data.get("age", "未回答")
        user_data["job"] = st.session_state.user_data.get("job", "未回答")
        user_data["bfi"] = st.session_state.user_data.get("bfi", None)
        user_data["emcs"] = st.session_state.user_data.get("emcs", None)
        user_data["life"] = st.session_state.user_data.get("life", None)

        # --- Azure Blob Storage 接続情報 ---
        # 環境変数から接続文字列とコンテナ名を取得
        # これらは後ほどAzureの画面で設定します
        CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
        CONTAINER_NAME = "results" # 作成するコンテナ名

        def save_to_blob(data):
            """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
            if not CONNECT_STR:
                st.error("Azureの接続文字列が設定されていません。")
                return

            try:
                file_name = f"survey_result_{user_data['user_id']}.json"

                # JSONデータに変換
                json_data = json.dumps(data, indent=2, ensure_ascii=False)

                # Blob Service Clientを作成
                blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

                # コンテナが存在しない場合は作成
                try:
                    blob_service_client.create_container(CONTAINER_NAME)
                except Exception as e:
                    # 既に存在する場合のエラーは無視
                    pass

                # Blob Clientを取得してアップロード
                blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

                blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

                st.success(f"回答が正常に保存されました！ ブラウザを閉じても大丈夫です")

            except Exception as e:
                st.error(f"データの保存中にエラーが発生しました: {e}")

        save_to_blob(user_data)