import streamlit as st

st.header("人生グラフの作成をした後、2つのアンケートに答えてください")
st.info("""回答中は、ブラウザの戻るボタンやリロードはしないでください。
        万が一その操作を行うとそれまでの回答データが失われ、最初からやり直しとなる可能性があります。""")
if st.button("開始"):
        st.session_state.role =  "Info1"
        st.rerun()