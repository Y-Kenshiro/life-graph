import streamlit as st
import json
import os
from azure.storage.blob import BlobServiceClient

st.header("回答完了")
st.write("お疲れさまでした！ご協力ありがとうございます")
user_data = {}
user_data["user_id"] = st.session_state.user_data.get("user_id", "")
user_data["gender"] = st.session_state.user_data.get("gender", "")
user_data["age"] = st.session_state.user_data.get("age", "未回答")
user_data["job"] = st.session_state.user_data.get("job", "未回答")
user_data["tipi"] = st.session_state.user_data.get("tipi", None)
user_data["pvq"] = st.session_state.user_data.get("pvq", None)
#user_data["bfi"] = st.session_state.user_data.get("bfi", None)
#user_data["emcs"] = st.session_state.user_data.get("emcs", None)
user_data["life"] = st.session_state.user_data.get("life", None)
user_data["graph_start"] = st.session_state.user_data.get("graph_start", None)
user_data["graph_end"] = st.session_state.user_data.get("graph_end", None)
user_data["test_start"] = st.session_state.user_data.get("test_start", None)
user_data["test_end"] = st.session_state.user_data.get("test_end", None)
user_data["error_fixed"] = st.session_state.user_data.get("error_fixed", None)


# --- Azure Blob Storage 接続情報 ---
# 環境変数から接続文字列とコンテナ名を取得
# これらは後ほどAzureの画面で設定します
CONNECT_STR = os.getenv('AZURE_STORAGE_CONNECTION_STRING')
CONTAINER_NAME = "completed-results" # 作成するコンテナ名

def save_to_blob(data):
    """アンケート結果をJSONファイルとしてAzure Blob Storageに保存する関数"""
    if not CONNECT_STR:
        st.error("Azureの接続文字列が設定されていません。")
        return

    try:
        file_name = f"survey_result_{user_data['user_id']}.json"

        # JSONデータに変換
        json_data = json.dumps(data, indent=2, ensure_ascii=False)

        # Blob Service Clientを作成
        blob_service_client = BlobServiceClient.from_connection_string(CONNECT_STR)

        # コンテナが存在しない場合は作成
        try:
            blob_service_client.create_container(CONTAINER_NAME)
        except Exception as e:
            # 既に存在する場合のエラーは無視
            pass

        # Blob Clientを取得してアップロード
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=file_name)

        blob_client.upload_blob(json_data, blob_type="BlockBlob", overwrite=True)

        st.success(f"回答が正常に保存されました！ ブラウザを閉じても大丈夫です")

    except Exception as e:
        st.error(f"データの保存中にエラーが発生しました: {e}")

save_to_blob(user_data)