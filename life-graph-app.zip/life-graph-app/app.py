import streamlit as st

# ---セッション状態の初期化---
if "role" not in st.session_state:
    st.session_state.role = "Agree"

if 'user_data' not in st.session_state:
    st.session_state.user_data = {
        "user_id": "",
        "gender": "",
        "age": None,
        "job": "",
        "tipi": None,
        "pvq":None,
        "life": None,
        "graph_start":None,
        "graph_end":None,
        "test_start":None,
        "test_end":None,
        "error_time":None,
        "error_fixed":None
    }

# ---ページ遷移や状態を操作する関数---
def start():
    st.session_state.role = "Agree"

def end():
    st.session_state.role = None
    for key in list(st.session_state.keys()):
        if key != "role":
            del st.session_state[key]

# ---ページの定義---
agree_page = st.Page(
    "detail/agreement.py",
    title="同意確認",
    icon=":material/gavel:",
    default=True
)
start_page = st.Page(
    "detail/start.py",
    title="開始",
    icon=":material/play_circle:"
)
info_1 = st.Page(
    "info/info_1.py",
    title="アンケート",
    icon=":material/task:"
)
info_2 = st.Page(
    "info/info_2.py",
    title="性格診断",
    icon=":material/psychology_alt:"
)
info_3 = st.Page(
    "info/info_3.py",
    title="エピソードテスト",
    icon=":material/edit_document:"
)
graph_2 = st.Page(
    "graph/graph_2.py",
    title="人生グラフ",
    icon=":material/show_chart:"
)
check_data = st.Page(
    "detail/check_data.py",
    title="回答確認",
    icon=":material/check_circle:"
)
explain = st.Page(
    "detail/explain.py",
    title="連絡先情報",
    icon=":material/info:"
)
end_page = st.Page(
    end,
    title="解答を破棄する(同意を撤回する)",
    icon=":material/exit_to_app:",
    url_path="exit_app"
)

main_page={}
if st.session_state.role == "Agree":
    main_page["同意確認"] = [agree_page]
if st.session_state.role == "Start":
    main_page["開始"] = [start_page]
if st.session_state.role == "Info1":
    main_page["アンケート"] = [info_1]
if st.session_state.role == "Info2":
    main_page["BFI"] = [info_2]
if st.session_state.role == "Info3":
    main_page["エピソードテスト"] = [info_3]
if st.session_state.role == "Graph":
    main_page["人生グラフ"] = [graph_2]
if st.session_state.role == "Check":
    main_page["回答確認"] = [check_data]

sub_pages = [explain,end_page]

# ナビゲーションを構築
pg = st.navigation(main_page | {"その他": sub_pages})

pg.run()
