# life-graph-app
研究用のウェブアプリ
Azureにアップロードすると機能

# ローカル実行
$ streamlit run app.py